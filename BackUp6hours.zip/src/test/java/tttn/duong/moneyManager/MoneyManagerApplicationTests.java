package tttn.duong.moneyManager;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MoneyManagerApplicationTests {

	@Test
	void contextLoads() {
	}

}
